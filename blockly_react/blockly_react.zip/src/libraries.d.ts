declare module 'react-blockly'{
    declare var BlocklyWorkspace: any;
}
