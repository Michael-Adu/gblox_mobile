#include <Arduino.h>
#include "othera.h"
#include "otherb.h"
void setup();
void loop();
#line 1 "src/sketch.pde"
//#include "othera.h"
//#include "otherb.h"

/**
 * asd
 */
void setup()
{
}

void loop()
{
}
