#ifndef CAT_H
#define CAT_H

class Cat {
 public:
  Cat();
  void meow();
};

#endif
