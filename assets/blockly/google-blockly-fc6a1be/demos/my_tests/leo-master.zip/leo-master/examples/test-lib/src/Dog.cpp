#include "Dog.h"

Dog::Dog(){

}

void Dog::bark(){
  // bark...
}
