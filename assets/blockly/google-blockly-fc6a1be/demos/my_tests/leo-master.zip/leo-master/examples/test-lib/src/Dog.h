#ifndef DOG_H
#define DOG_H

class Dog {
 public:
  Dog();
  void bark();
};

#endif
