
var boards = require('../../boards.js');

module.exports.fake = {
  name: 'Fake Board'
};

