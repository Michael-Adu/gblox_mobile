///Variable Counter
var digital_pin_number = 0;
var analog_pin_number = 0;

///Start and End Blocks

//Start Block
Blockly.Blocks['start_block'] = {
  init: function() {
    this.appendDummyInput()
        .appendField("Start Arduino")
        .appendField(new Blockly.FieldCheckbox("TRUE"), "Arduino Start");
    this.setInputsInline(false);
    this.setNextStatement(true, null);
    this.setColour(140);
 this.setTooltip("");
 this.setHelpUrl("");
  }
};

Blockly.JavaScript['start_block'] = function(block) {
  var checkbox_arduino_start = block.getFieldValue('Arduino Start') == 'TRUE';
  // TODO: Assemble JavaScript into code variable.
  if (checkbox_arduino_start==true){
    var code = 'new five = require("johnny-five");\nnew board = new five.Board();\nboard.on("ready",function(){\n'
  }
  else{
    var code = "";
  }
  return code;
};

//End Block
Blockly.Blocks['end_block'] = {
  init: function() {
    this.appendDummyInput()
        .appendField("End Arduino");
    this.setPreviousStatement(true, null);
    this.setColour(140);
 this.setTooltip("");
 this.setHelpUrl("");
  }
};

Blockly.JavaScript['end_block'] = function(block) {
  // TODO: Assemble JavaScript into code variable.
  var code = '\n\n}';
  return code;
};
///Digital Blocks

//Digital Pin Write
Blockly.Blocks['digital_pin_write'] = {
    init: function() {
      this.appendValueInput("Pin number")
          .setCheck("Number")
          .setAlign(Blockly.ALIGN_CENTRE)
          .appendField("Digital Pin")
          .appendField(new Blockly.FieldNumber(0, 0, 19), "Digital Pin Number");
      this.appendValueInput("NAME")
          .setCheck("Boolean")
          .setAlign(Blockly.ALIGN_CENTRE)
          .appendField("On/Off")
          .appendField(new Blockly.FieldDropdown([["Off","Off"], ["On","On"]]), "On/Off");
      this.setPreviousStatement(true, null);
      this.setNextStatement(true, null);
      this.setColour(20);
   this.setTooltip("");
   this.setHelpUrl("");
    }
  };

Blockly.JavaScript['digital_pin_write'] = function(block) {
    var number_digital_pin_number = block.getFieldValue('Digital Pin Number');
    var value_pin_number = Blockly.JavaScript.valueToCode(block, 'Pin number', Blockly.JavaScript.ORDER_ATOMIC);
    var dropdown_on_off = block.getFieldValue('On/Off');
    var value_name = Blockly.JavaScript.valueToCode(block, 'NAME', Blockly.JavaScript.ORDER_ATOMIC);
    // TODO: Assemble JavaScript into code variable.
    digital_pin_number=digital_pin_number+1;
    if (dropdown_on_off=="Off"){
      var state = '0';
    }
    else{
      var state = '1';
    };
    var code = '\n\tvar digital_pin'+ digital_pin_number + '= new five.Pin('+number_digital_pin_number+');\n\tdigital_pin'+ digital_pin_number+'.write('+ state + ');';
    return code;
  };


//Digital Pin Read
Blockly.Blocks['digital_read'] = {
  init: function() {
    this.appendValueInput("NAME")
        .setCheck(null)
        .appendField("Digital Pin")
        .appendField(new Blockly.FieldNumber(0, 0, 19), "Digital Pin Number");
    this.setOutput(true, null);
    this.setColour(20);
 this.setTooltip("");
 this.setHelpUrl("");
  }
};

Blockly.JavaScript['digital_read'] = function(block) {
  var number_digital_pin_number = block.getFieldValue('Digital Pin Number');
  var value_name = Blockly.JavaScript.valueToCode(block, 'NAME', Blockly.JavaScript.ORDER_ATOMIC);
  // TODO: Assemble JavaScript into code variable.
  var code = '...';
  // TODO: Change ORDER_NONE to the correct strength.
  return [code, Blockly.JavaScript.ORDER_NONE];
};

///Analog Blocks

//Analog Write
Blockly.Blocks['analog_write'] = {
    init: function() {
      this.appendValueInput("Arduino Pin")
          .setCheck("Number")
          .appendField("Analog Pin")
          .appendField(new Blockly.FieldTextInput("0"), "Pin Number");
      this.appendValueInput("Analog Write")
          .setCheck("Number")
          .appendField("Output Value")
          .appendField(new Blockly.FieldNumber(0, 0, 100), "Duty Cycle");
      this.setInputsInline(false);
      this.setPreviousStatement(true, null);
      this.setNextStatement(true, null);
      this.setColour(210);
   this.setTooltip("");
   this.setHelpUrl("");
    }
  };

  Blockly.JavaScript['analog_write'] = function(block) {
    var number_duty_cycle = block.getFieldValue('Duty Cycle');
    var value_analog_write = Blockly.JavaScript.valueToCode(block, 'Analog Write', Blockly.JavaScript.ORDER_ATOMIC);
    var text_pin_number = block.getFieldValue('Pin Number');
    var value_arduino_pin = Blockly.JavaScript.valueToCode(block, 'Arduino Pin', Blockly.JavaScript.ORDER_ATOMIC);
    // TODO: Assemble JavaScript into code variable.
    var code = '...;';
    return code;
  };

  //Analog Read
  Blockly.Blocks['analog_read'] = {
    init: function() {
      this.appendValueInput("NAME")
          .setCheck("Number")
          .setAlign(Blockly.ALIGN_CENTRE)
          .appendField("Analog Pin")
          .appendField(new Blockly.FieldNumber(0, 1, 5), "Analog PIn");
      this.setOutput(true, null);
      this.setColour(190);
   this.setTooltip("");
   this.setHelpUrl("");
    }
  };

  Blockly.JavaScript['analog_read'] = function(block) {
    var number_analog_pin = block.getFieldValue('Analog Pin');
    var value_name = Blockly.JavaScript.valueToCode(block, 'NAME', Blockly.JavaScript.ORDER_ATOMIC);
    // TODO: Assemble JavaScript into code variable.
    var code = '...';
    // TODO: Change ORDER_NONE to the correct strength.
    return [code, Blockly.JavaScript.ORDER_NONE];
  };

  ///Sensors Blocks

  //Ultrasonic Sensor

  Blockly.Blocks['ultrasonic_sensor'] = {
    init: function() {
      this.appendValueInput("Trigger")
          .setCheck("Number")
          .appendField("Trigger Pin")
          .appendField(new Blockly.FieldNumber(0, 0, 19), "Trigger Digital Pin");
      this.appendValueInput("Echo")
          .setCheck("Number")
          .appendField("Echo Pin")
          .appendField(new Blockly.FieldNumber(0, 0, 19), "Echo Digital Pin");
      this.setOutput(true, null);
      this.setColour(65);
   this.setTooltip("");
   this.setHelpUrl("");
    }
  };

  Blockly.JavaScript['ultrasonic_sensor'] = function(block) {
    var number_trigger_digital_pin = block.getFieldValue('Trigger Digital Pin');
    var value_trigger = Blockly.JavaScript.valueToCode(block, 'Trigger', Blockly.JavaScript.ORDER_ATOMIC);
    var number_echo_digital_pin = block.getFieldValue('Echo Digital Pin');
    var value_echo = Blockly.JavaScript.valueToCode(block, 'Echo', Blockly.JavaScript.ORDER_ATOMIC);
    // TODO: Assemble JavaScript into code variable.
    var code = '...';
    // TODO: Change ORDER_NONE to the correct strength.
    return [code, Blockly.JavaScript.ORDER_NONE];
  };