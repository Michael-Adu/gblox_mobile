# Icon

<aside>
💡 Icons for the splash screen and the logo of the app. Used in [pubspec.yaml](pubspec%20yaml%207a79394f584e4d41ac2c092e254a335d.md)

</aside>