# Fonts

<aside>
💡 Default fonts loaded to the device. Currently Baloo 2

</aside>