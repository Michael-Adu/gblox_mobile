# Developers/UI Designers

- Samuel Osei - Developer
- Gideon Ankonu - UI Designer
- Michael Nimdea-Gyan Adu - Developer
- Terry Selasie Tettey - Developer