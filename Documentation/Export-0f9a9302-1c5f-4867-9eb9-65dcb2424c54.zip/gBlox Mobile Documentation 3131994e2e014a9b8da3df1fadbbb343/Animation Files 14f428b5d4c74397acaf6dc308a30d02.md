# Animation Files

<aside>
💡 Used for Rive animations in [Path Finder](Path%20Finder%20927e9f212df34670b4441b5e50dec734.md)

</aside>