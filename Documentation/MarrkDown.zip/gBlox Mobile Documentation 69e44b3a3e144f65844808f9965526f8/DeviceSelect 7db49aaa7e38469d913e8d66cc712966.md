# DeviceSelect

<aside>
💡

</aside>

# Modular Widgets Used

1. *Cards - `gblox_mobile\lib\components\Modular_Widgets\Cards`*

# Pages Used

1. Code Menu - *`gblox_mobile\lib\components\Menus\CodeMenu\code_menu.dart`*
2. Play Menu - *`gblox_mobile\lib\components\Menus\ModeSelector\mode_select.dart`*

![Untitled](DeviceSelect%207db49aaa7e38469d913e8d66cc712966/Untitled.png)

# Select Device

- Upon the user tapping the device, if the user selected their device from the home screen, they will be sent to the `ModeSelector`. The device chosen is stored in `global_variables.dart` in `selectedDevice`. This is used for  [Blockly](Blockly%200a30f6dea44a4764977494fb751bfbbe.md) and is available for any other page.

# What is Left?